====================================================================
GLOW CADENCE — CUSTOM TESLA & CYBERTRUCK LIGHT SHOW SETUP GUIDE
====================================================================

Thank you for downloading this custom Tesla Light Show by Glow Cadence!

--------------------------------------------------------------------
1. HOW TO RUN THIS LIGHT SHOW ON YOUR TESLA OR CYBERTRUCK
--------------------------------------------------------------------
1. Format a USB flash drive as exFAT, FAT32 (Windows), or MS-DOS FAT (Mac).
   - Note: Do NOT include a "TeslaCam" folder on the same partition, or
     use a separate USB drive/partition dedicated to LightShow.
2. At the root directory of the USB drive, make sure there is a folder
   named exactly:
       LightShow
   (Case-sensitive: capital L, capital S, no spaces.)
3. Place both files inside the `LightShow` folder:
       LightShow/lightshow.fseq
       LightShow/lightshow.mp3
   (Note: On newer Tesla firmware supporting multi-show USB drives, you can
   also keep custom-named pairs like `Seoul-Midnight-Drift.fseq` and
   `Seoul-Midnight-Drift.mp3` inside the `LightShow` folder.)
4. Plug the USB drive into a data-enabled front USB port (or glovebox USB
   port, depending on your vehicle model).
5. On your Tesla touchscreen, open:
       Toybox -> Light Show -> Schedule Show
6. Select your song, step outside the vehicle, close all doors, and enjoy!

--------------------------------------------------------------------
2. COMPATIBILITY & CHOREOGRAPHY ARCHITECTURE
--------------------------------------------------------------------
- Cybertruck: Full native support for the 60-LED front lightbar, 52-LED
  rear lightbar, exterior lighting, interior RGB ambient strips, and
  synchronized motorized closures (frunk, tonneau, charge port, windows).
- Model S, Model 3, Model X, and Model Y (2021+ & Highland/Juniper):
  100% compatible across all standard exterior lighting & closure channels.
- Beat-locked to true audio transients (kick, snare, bass, and melodic
  stems) rather than generic random blinking.

--------------------------------------------------------------------
3. CLAIM ANOTHER FREE SHOW & EXPLORE ALL 55 SHOWS
--------------------------------------------------------------------
Want another free custom light show?
Visit https://glowcadence.com to claim an additional free light show when
you sign up, and explore our complete catalog of 55 custom-choreographed
Tesla & Cybertruck light shows!

Website: https://glowcadence.com
Support: hello@glowcadence.com

Not affiliated with Tesla, Inc. "Tesla" and "Cybertruck" are trademarks of
Tesla, Inc., used strictly for compatibility identification.
====================================================================
